from .jimner import jimner
__name__ = "jimner"
__author__ = "Jimut Bahan Pal | jimutbahanpal@yahoo.com"

